jQuery(window).load(function (e) {
	jQuery("img").peHotSpot();	
});

